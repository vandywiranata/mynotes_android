package com.android.mynotes.data;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.android.mynotes.model.Notes;

@Dao
public interface NotesDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertNotes(Notes notes);

    @Update
    int updateNotes(Notes notes);

    @Delete
    int deleteNotes(Notes notes);

    @Query("SELECT * FROM tnotes")
    Notes[] selectAllNotes();

}
