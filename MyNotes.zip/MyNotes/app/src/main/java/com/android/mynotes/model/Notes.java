package com.android.mynotes.model;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.io.Serializable;

@Entity (tableName = "tnotes")
public class Notes implements Serializable {
    @PrimaryKey(autoGenerate = true)
    public int notesId;

    @ColumnInfo(name = "notes_subject")
    public String notesSubject;

    @ColumnInfo(name = "notes_notes")
    public String notesNotes;

    @ColumnInfo(name = "notes_date")
    public String notesDate;

    public int getNotesId() {
        return notesId;
    }

    public void setNotesId(int barangId) {
        this.notesId = notesId;
    }

    public String getNotesSubject() {
        return notesSubject;
    }

    public void setNotesSubject(String notesSubject) {this.notesSubject = notesSubject; }

    public String getNotesNotes() {
        return notesNotes;
    }

    public void setNotesNotes(String notesNotes) {this.notesNotes = notesNotes; }

    public String getNotesDate() {
        return notesDate;
    }

    public void setNotesDate(String notesDate) {
        this.notesDate = notesDate;
    }
}
