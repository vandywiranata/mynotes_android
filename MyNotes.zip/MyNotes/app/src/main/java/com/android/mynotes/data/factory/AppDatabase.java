package com.android.mynotes.data.factory;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.android.mynotes.data.NotesDAO;
import com.android.mynotes.model.Notes;

@Database(entities = {Notes.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract NotesDAO notesDAO();
}
